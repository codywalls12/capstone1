from django.contrib import admin
from .models import GraphModel, graphpoint
# Register your models here.
admin.site.register(GraphModel)
admin.site.register(graphpoint)